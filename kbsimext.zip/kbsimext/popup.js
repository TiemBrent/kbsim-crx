let activeButton = null;

document.addEventListener("DOMContentLoaded", function () {
    const soundToggleButton = document.getElementById("toggleSoundButton");
    const soundButtons = document.querySelectorAll("#soundButtons button");

    // Retrieve previously selected sound
    chrome.storage.sync.get("selectedSound", function (data) {
        if (data.selectedSound) {
            const selectedButton = document.querySelector(`#${data.selectedSound}`);
            if (selectedButton) {
                selectedButton.classList.add("active"); // Use "active" class for the selected button
                activeButton = selectedButton; // Set the active button
            }
        }
    });

    // Retrieve the sound enabled state
    chrome.storage.sync.get("soundEnabled", function (data) {
        if (data.soundEnabled) {
            soundToggleButton.classList.remove("off");
            soundToggleButton.classList.add("on");
            soundToggleButton.textContent = "Turn Off";
        } else {
            soundToggleButton.classList.remove("on");
            soundToggleButton.classList.add("off");
            soundToggleButton.textContent = "Turn On";
        }
    });

    // Add event listener to toggle sound on and off
    soundToggleButton.addEventListener("click", function () {
        const soundEnabled = soundToggleButton.classList.contains("off");

        chrome.storage.sync.set({ soundEnabled: soundEnabled }, function () {
            if (soundEnabled) {
                soundToggleButton.classList.remove("off");
                soundToggleButton.classList.add("on");
                soundToggleButton.textContent = "Turn Off";
            } else {
                soundToggleButton.classList.remove("on");
                soundToggleButton.classList.add("off");
                soundToggleButton.textContent = "Turn On";
            }
        });
    });

    // Add event listeners to each sound button
    soundButtons.forEach(button => {
        button.addEventListener("click", function () {
            // Remove active class from previously active button
            if (activeButton) {
                activeButton.classList.remove("active");
            }
            // Add active class to the clicked button
            this.classList.add("active");
            activeButton = this; // Update the active button reference

            const selectedSound = this.id;  // id of the clicked button (e.g., 'alpaca', 'blackink', etc.)

            chrome.storage.sync.set({ selectedSound: selectedSound }, function () {
                // Update UI: Highlight selected button
                soundButtons.forEach(btn => btn.classList.remove("selected"));
                button.classList.add("selected");
            });
        });
    });
});
document.addEventListener("DOMContentLoaded", function () {
    const soundToggleButton = document.getElementById("toggleSoundButton");
    const soundButtons = document.querySelectorAll("#soundButtons button");

    // Retrieve previously selected sound
    chrome.storage.sync.get("selectedSound", function (data) {
        if (data.selectedSound) {
            document.querySelector(`#${data.selectedSound}`).classList.add("selected");
        }
    });

    // Retrieve the sound enabled state
    chrome.storage.sync.get("soundEnabled", function (data) {
        if (data.soundEnabled) {
            soundToggleButton.classList.remove("off");
            soundToggleButton.classList.add("on");
            soundToggleButton.textContent = "Turn Off";
        } else {
            soundToggleButton.classList.remove("on");
            soundToggleButton.classList.add("off");
            soundToggleButton.textContent = "Turn On";
        }
    });

    // Add event listener to toggle sound on and off
    soundToggleButton.addEventListener("click", function () {
        const soundEnabled = soundToggleButton.classList.contains("off");

        chrome.storage.sync.set({ soundEnabled: soundEnabled }, function () {
            if (soundEnabled) {
                soundToggleButton.classList.remove("off");
                soundToggleButton.classList.add("on");
                soundToggleButton.textContent = "Turn Off";
            } else {
                soundToggleButton.classList.remove("on");
                soundToggleButton.classList.add("off");
                soundToggleButton.textContent = "Turn On";
            }
        });
    });

    // Add event listeners to each sound button
    soundButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedSound = this.id;  // id of the clicked button (e.g., 'alpaca', 'blackink', etc.)

            chrome.storage.sync.set({ selectedSound: selectedSound }, function () {
                // Update UI: Highlight selected button
                soundButtons.forEach(btn => btn.classList.remove("selected"));
                button.classList.add("selected");
            });
        });
    });
});
