// Utility function to get sound settings
function getSoundSettings(callback) {
    chrome.storage.sync.get("soundEnabled", function (data) {
        callback(data.soundEnabled);
    });
}

// Function to get the selected sound set
function getSelectedSound(callback) {
    chrome.storage.sync.get("selectedSound", function (data) {
        callback(data.selectedSound || "alpaca"); // Default to "alpaca" if no selection
    });
}

// Listen for key presses
document.addEventListener("keydown", function (event) {
    // Check if sound is enabled directly from chrome storage
    getSoundSettings(function (soundEnabled) {
        if (!soundEnabled) return; // If disabled, don't play sound

        getSelectedSound(function (selectedSound) {
            const keysNoSound = [
                "Escape", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "Power"
            ];

            // Define key mappings for each row
           const keysR0 = ["Backquote", "Digit1", "Digit2", "Digit3", "Digit4", "Digit5", "Digit6", "Digit7", "Digit8", "Digit9", "Digit0", "Minus", "Equal"];
            const keysR1 = ["Tab", "KeyQ", "KeyW", "KeyE", "KeyR", "KeyT", "KeyY", "KeyU", "KeyI", "KeyO", "KeyP", "BracketLeft", "BracketRight", "Backslash"];
            const keysR2 = ["CapsLock", "KeyA", "KeyS", "KeyD", "KeyF", "KeyG", "KeyH", "KeyJ", "KeyK", "KeyL", "Semicolon", "Quote"];
            const keysR3 = ["ShiftLeft", "KeyZ", "KeyX", "KeyC", "KeyV", "KeyB", "KeyN", "KeyM", "Comma", "Period", "Slash", "ShiftRight"];
            const keysR4 = ["ControlLeft", "AltLeft", "AltRight", "ControlRight", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"];

            let soundFile = null;

            if (keysNoSound.includes(event.code)) return;

            // Assign sound files based on the row and selected sound set
            if (keysR0.includes(event.code)) soundFile = `${selectedSound}/press/GENERIC_R0.mp3`;
            if (keysR1.includes(event.code)) soundFile = `${selectedSound}/press/GENERIC_R1.mp3`;
            if (keysR2.includes(event.code)) soundFile = `${selectedSound}/press/GENERIC_R2.mp3`;
            if (keysR3.includes(event.code)) soundFile = `${selectedSound}/press/GENERIC_R3.mp3`;
            if (keysR4.includes(event.code)) soundFile = `${selectedSound}/press/GENERIC_R4.mp3`;

            // Special cases for Backspace, Enter, and Space
            if (event.code === "Backspace") soundFile = `${selectedSound}/press/BACKSPACE.mp3`;
            if (event.code === "Enter") soundFile = `${selectedSound}/press/ENTER.mp3`;
            if (event.code === "Space") soundFile = `${selectedSound}/press/SPACE.mp3`;

            if (soundFile) {
                // Create a new Audio object for each sound to allow overlapping
                const audio = new Audio(chrome.runtime.getURL(soundFile));
                audio.play().catch(e => console.error("Audio play error:", e));
            }
        });
    });
});

// Listen for key release
document.addEventListener("keyup", function (event) {
    // Check if sound is enabled directly from chrome storage
    getSoundSettings(function (soundEnabled) {
        if (!soundEnabled) return; // If disabled, don't play sound

        getSelectedSound(function (selectedSound) {
            // Always use the same generic release sound
            const soundFile = `${selectedSound}/release/GENERIC.mp3`;

            if (soundFile) {
                // Create a new Audio object for each sound to allow overlapping
                const audio = new Audio(chrome.runtime.getURL(soundFile));
                audio.play().catch(e => console.error("Audio play error:", e));
            }
        });
    });
});
